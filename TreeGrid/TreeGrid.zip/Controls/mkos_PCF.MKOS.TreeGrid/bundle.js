var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./TreeGrid/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./TreeGrid/index.ts":
/*!***************************!*\
  !*** ./TreeGrid/index.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n/*\r\n/// <reference types=\"@types/[jstree]\" />\r\n*/\n\nvar jsTreeNodeState =\n/** @class */\nfunction () {\n  function jsTreeNodeState() {}\n\n  return jsTreeNodeState;\n}();\n\nvar jsTreeNode =\n/** @class */\nfunction () {\n  function jsTreeNode() {}\n\n  return jsTreeNode;\n}();\n\nvar TreeGrid =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function TreeGrid() {\n    this.treeData = [];\n    this.selectedItems = [];\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  TreeGrid.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.contextObj = context; // Need to track container resize so that control could get the available width. The available height won't be provided even this is true\n\n    context.mode.trackContainerResize(true); // Create main table container div. \n\n    this.mainContainer = document.createElement(\"div\");\n    this.controlId = \"foo\";\n    this.mainContainer.innerHTML = \"\\n\\t\\t\\n\\t\\t\\t<input id=\\\"search-input\\\" class=\\\"search-input\\\" placeholder=\\\"Type to search...\\\" />\\n\\t\\t\\t<br />\\n\\t\\t\\t<div id=\\\"\" + this.controlId + \"\\\" class=\\\"jstree-open\\\" style=\\\"height: 62vh; overflow-y: auto; overflow-x: hidden;\\\">\\n\\t\\t\\t  <ul>\\n\\t\\t\\t\\t\\n\\t\\t\\t  </ul>\\n\\t\\t\\t</div>\\n\\t\\t\";\n    this._initTreeHandler = this.initTree.bind(this);\n    var scriptElement = document.createElement(\"script\");\n    scriptElement.src = \"https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js\";\n    scriptElement.type = \"text/javascript\";\n    container.appendChild(scriptElement);\n    container.appendChild(this.mainContainer);\n    var scriptElementOnLoad = document.createElement(\"script\");\n    scriptElementOnLoad.type = \"text/javascript\";\n    scriptElementOnLoad.innerHTML = \"\\n\\t\\t    initTreeControl();\\n\\t\\t\\t\\n\\t\\t\\tfunction initTreeControl()\\n\\t\\t\\t{\\n\\t\\t\\t\\tif(typeof($('#\" + this.controlId + \"').jstree) == 'undefined')\\n\\t\\t\\t\\t{\\n\\t\\t\\t\\t\\tsetTimeout(initTreeControl, 500);\\n\\t\\t\\t\\t}\\n\\t\\t\\t\\telse\\n\\t\\t\\t\\t{\\n\\t\\t\\t\\t\\twindow.top.\" + this.controlId + \"= $('#\" + this.controlId + \"');\\n\\t\\t\\t\\t\\t\\n\\t\\t\\t\\t}\\n\\t\\t\\t}\\t\\t\\t\\n\\n\\t\\t\\t$(document).ready(function () {\\n\\t\\t\\t\\t$(\\\".search-input\\\").keyup(function () {\\t\\t\\t\\t\\t\\n\\t\\t\\t\\t\\tvar searchString = $(\\\".search-input\\\").val();\\n\\t\\t\\t\\t\\t$('#\" + this.controlId + \"').jstree('search', searchString);\\n\\t\\t\\t\\t});\\n\\t\\t\\t\\n\\t\\t\\t});\\n\\t\\t\";\n    this.container.appendChild(scriptElementOnLoad);\n\n    if (context.parameters.treeEntityName != null) {\n      this._treeEntityName = context.parameters.treeEntityName.raw;\n      this._treeNodeId = this._treeEntityName + \"id\";\n    }\n\n    if (context.parameters.treeNodeParentAttribute != null) this._treeParentAttribute = '_' + context.parameters.treeNodeParentAttribute.raw + '_value';\n    if (context.parameters.treeNodeRootAttribute != null) this._treeRootAttribute = '_' + context.parameters.treeNodeRootAttribute.raw + '_value';\n    if (context.parameters.treeNodeNameAttribute != null) this._treeNodeName = context.parameters.treeNodeNameAttribute.raw.toString();\n    this._successCallback = this.successCallback.bind(this);\n    this._findRootCallback = this.findRootCallback.bind(this);\n    this._setRootCallback = this.setRootCallback.bind(this);\n    this._onNodeCheckClick = this.nodeClick.bind(this);\n    this._entityMetadataSuccessCallback = this.entityMetadataSuccessCallback.bind(this);\n    Xrm.Utility.getEntityMetadata(this.contextObj.page.entityTypeName, []).then(this._entityMetadataSuccessCallback, this.errorCallback); // Get root id\t\n\n    this.contextObj.webAPI.retrieveRecord(this.contextObj.page.entityTypeName, this.contextObj.page.entityId, \"?$select=\" + this._treeRootAttribute + \",\" + this._treeNodeId).then(this._findRootCallback, this.errorCallback);\n  };\n\n  TreeGrid.prototype.entityMetadataSuccessCallback = function (value) {\n    this._mainEntityCollectionName = value.EntitySetName;\n  };\n\n  TreeGrid.prototype.addElements = function (value) {\n    try {\n      // console.log(\"addElements:\");\n      for (var i in value.entities) {\n        var current = value.entities[i];\n        var newNode = new jsTreeNode();\n        newNode.id = current[this._treeNodeId];\n        newNode.text = current[this._treeNodeName];\n        newNode.parent = current[this._treeParentAttribute];\n        this.treeData.push(newNode);\n      } // console.log(this.treeData);\n\n    } catch (error) {\n      console.log(error);\n    }\n  }; // find the top node\n\n\n  TreeGrid.prototype.findRootCallback = function (value) {\n    try {\n      // console.log(\"findRootCallback:\")\n      // console.log(value);\n      var rootId = value[this._treeNodeId];\n      if (value[this._treeRootAttribute]) rootId = value[this._treeRootAttribute];\n      this.contextObj.webAPI.retrieveRecord(this.contextObj.page.entityTypeName, rootId).then(this._setRootCallback, this.errorCallback);\n    } catch (error) {\n      console.log(error);\n    }\n  }; // set top node of tree\n\n\n  TreeGrid.prototype.setRootCallback = function (value) {\n    try {\n      // console.log(\"setRootCallback:\")\n      // console.log(value);\n      var root = new jsTreeNode();\n      root.id = value[this._treeNodeId];\n      root.text = value[this._treeNodeName];\n      root.parent = \"#\";\n      this.treeData.push(root); // filter all records that are related to the root attribute\n\n      var filter = \"?$filter=\" + this._treeRootAttribute + \" eq \" + value[this._treeNodeId] + \"&$orderby=\" + this._treeNodeName + \" asc\"; // console.log(\"setRootCallback: \" + filter);\n\n      this.contextObj.webAPI.retrieveMultipleRecords(this._treeEntityName, filter, 5000).then(this._successCallback, this.errorCallback);\n    } catch (error) {\n      console.log(error);\n    }\n  };\n\n  TreeGrid.prototype.successCallback = function (value) {\n    try {\n      // console.log(\"successCallback:\");\n      // console.log(value);\n      this.addElements(value);\n      this.initTree();\n    } catch (error) {\n      console.log(error);\n    }\n  };\n\n  TreeGrid.prototype.errorCallback = function (value) {\n    console.log(value);\n  };\n\n  TreeGrid.prototype.initTree = function () {\n    try {\n      // console.log(\"initTree:\");\n      if (window.top[this.controlId].jstree == null) {\n        setTimeout(this._initTreeHandler, 500);\n      } else {\n        window.top[this.controlId].jstree({\n          \"plugins\": [\"state\", \"search\"],\n          \"state\": {\n            \"key\": \"treekey\"\n          },\n          \"search\": {\n            \"case_sensitive\": false //\"show_only_matches\": true\n\n          },\n          \"core\": {\n            \"data\": this.treeData,\n            \"multiple\": false\n          }\n        }).on('select_node.jstree', function (e, data) {\n          if (data.event) {\n            data.instance.select_node(data.node.id);\n          }\n        }).on('deselect_node.jstree', function (e, data) {\n          if (data.event) {\n            data.instance.deselect_node(data.node.id);\n          }\n        });\n\n        var _self = this;\n\n        window.top[this.controlId].bind(\"changed.jstree\", function (e, data) {\n          setTimeout(function () {\n            _self._onNodeCheckClick(data);\n          }, 50);\n        });\n      }\n    } catch (error) {\n      console.log(error);\n    }\n  };\n\n  TreeGrid.prototype.nodeClick = function (data) {\n    try {\n      console.log(\"nodeClick:\");\n      console.log(data.event);\n\n      if (data.action == \"select_node\") {\n        if (typeof data.event != \"undefined\" && data.event.type == \"click\") {\n          console.log(\"click\");\n          var entityFormOptions = {};\n          entityFormOptions[\"entityName\"] = this.contextObj.page.entityTypeName;\n          entityFormOptions[\"entityId\"] = data.node.id; // Open the form.\n\n          Xrm.Navigation.openForm(entityFormOptions).then(function (success) {\n            console.log(success);\n          }, function (error) {\n            console.log(error);\n          });\n        }\n      }\n    } catch (error) {\n      console.log(error);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  TreeGrid.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  TreeGrid.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  TreeGrid.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return TreeGrid;\n}();\n\nexports.TreeGrid = TreeGrid;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TreeGrid/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCF.MKOS.TreeGrid', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TreeGrid);
} else {
	var PCF = PCF || {};
	PCF.MKOS = PCF.MKOS || {};
	PCF.MKOS.TreeGrid = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TreeGrid;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}